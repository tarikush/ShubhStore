<?php function menu_list(){ ?>
           <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">                
                <ul class="nav side-menu">
                  
                  <li><a><i class="fa fa-book"></i> Products <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add.php">Add Product</a></li>
                      <li><a href="update.php">Update Product</a></li>
                      <li><a href="delete.php">Delete Product</a></li>    
                    </ul>
                  </li>
                 <li><a href="bill.php"><i class="fa fa-list-alt"></i>Generate Bill</a>                   
                  </li>                  
                </ul>
              </div>
            </div>
<?php } ?>