<!doctype html>
                        <html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title>Shubh Bill</title>
                                <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='css/bill.css' rel='stylesheet'>
                                <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
                                <script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js'></script>
                                <script type='text/javascript'></script>
                            </head>
                            <body>
                            <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 padding">
    <div class="card">
        <div class="card-header p-4">
            <a class="pt-2 d-inline-block" href="index.php" data-abc="true"><img src="images/bill_logo.png"></a>
            <div class="float-right">
                <h3 class="mb-0">Invoice #BBB10234</h3>
                Date: 12 Jan,2020
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-sm-6">
                    <h5 class="mb-3">From:</h5>
                    <h3 class="text-dark mb-1">Shubh Stores</h3>
                    <div>Near Miramar Beach</div>
                    <div>Panjim Goa</div>
                    <div>Email: info@shubhstores.com</div>
                    <div>Phone: +91 9897 989 989</div>
                </div>
                <div class="col-sm-6 ">
                    <h5 class="mb-3">To:</h5>
                    <h3 class="text-dark mb-1">Akshay Singh</h3>
                    <div>478, Nai Sadak</div>
                    <div>Miramar Beach</div>
                    <div>Phone: +91 9895 398 009</div>
                </div>
            </div>
            <div class="table-responsive-sm">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th class="center">#</th>
                            <th>Item</th>
                            <th class="right">Price</th>
                            <th class="center">Qty</th>
							<th class="right">CGST %</th>
							<th class="right">SGST %</th>
                            <th class="right">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="center">1</td>
                            <td class="left strong">Rava 5 Kg</td>
                            <td class="right">&#8377;200</td>
                            <td class="center">5</td>
							<td class="right">18</td>
							<td class="right">15</td>
                            <td class="right">1,000</td>
                        </tr>
						<tr>
                            <td class="center">1</td>
                            <td class="left strong">Basmati Rice 25 Kg</td>
                            <td class="right">&#8377;800</td>
                            <td class="center">10</td>
							<td class="right">18</td>
							<td class="right">15</td>
                            <td class="right">8,000</td>
                        </tr>
						<tr>
                            <td class="center">1</td>
                            <td class="left strong">Basmati Rice 25 Kg</td>
                            <td class="right">&#8377;800</td>
                            <td class="center">10</td>
							<td class="right">18</td>
							<td class="right">15</td>
                            <td class="right">8,000</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-5">
                </div>
                <div class="col-lg-4 col-sm-5 ml-auto">
                    <table class="table table-clear">
                        <tbody>
                            <tr>
                                <td class="left">
                                    <strong class="text-dark">Subtotal</strong>
                                </td>
                                <td class="right">&#8377;17,000</td>
                            </tr>
                            <tr>
                                <td class="left">
                                    <strong class="text-dark">CGST</strong>
                                </td>
                                <td class="right">&#8377;400</td>
                            </tr>
                            <tr>
                                <td class="left">
                                    <strong class="text-dark">SGST</strong>
                                </td>
                                <td class="right">&#8377;400</td>
                            </tr>
                            <tr>
                                <td class="left">
                                    <strong class="text-dark">Total</strong> </td>
                                <td class="right">
                                    <strong class="text-dark">&#8377; 17,800</strong>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-footer bg-white">
            <p class="mb-0">Customer Sign</p>
        </div>
    </div>
	 <button type="submit" class="btn btn-success b_t" name="update">Print Bill</button>
</div>
                            </body>
                        </html>