<?php
	//connect database
	$connect = mysqli_connect ("localhost","root","","store") or die("Cannot connect to Database : ".mysqli_error());
	//mysqli_select_db("store") or die("Cannot connect to Database : ".mysqli_error());
?>